import React from 'react'
import Navbar from './Navbar'

function HomePage() {
  return (
    <div>
        <Navbar/>
    </div>
  )
}

export default HomePage